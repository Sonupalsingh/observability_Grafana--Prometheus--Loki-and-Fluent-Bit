# Observability Stack – Helm Chart

A self-contained Helm chart that deploys a complete **logging, metrics and alerting** stack on Kubernetes, with every component pre-wired to the others and **all data stored in a local directory on the node**.

| Component | Role | Version |
|---|---|---|
| **Fluent Bit** | Collects container logs from every node | 3.1.9 |
| **Loki** | Stores and indexes logs, evaluates log-based alert rules | 3.1.1 |
| **Prometheus** | Collects metrics, evaluates metric-based alert rules | 2.54.1 |
| **Alertmanager** | Groups alerts and sends them by email / Slack / webhook | 0.27.0 |
| **Grafana** | Dashboards, log search, alert overview | 11.2.0 |

No external storage, cloud services or operators are required: one command and everything is connected.

**Supported host operating systems**

| OS family | Tested / supported | Handled automatically |
|---|---|---|
| RHEL 8/9, Rocky, AlmaLinux, CentOS Stream, Oracle Linux, Fedora | ✅ | SELinux labels + `spc_t` pods, firewalld |
| Ubuntu 20.04 / 22.04 / 24.04, Debian 11/12 | ✅ | AppArmor (no changes needed), ufw, inotify limits |

Works with kubeadm, k3s and MicroK8s clusters, and with the CRI-O, containerd and Docker (cri-dockerd) container runtimes.

---

## Table of contents

1. [How it works](#1-how-it-works)
2. [Repository structure](#2-repository-structure)
3. [Prerequisites](#3-prerequisites)
4. [Quick start](#4-quick-start)
   - [RHEL vs Ubuntu: what is different](#47-rhel-vs-ubuntu-what-is-different)
5. [Accessing the UIs](#5-accessing-the-uis)
6. [Configuration](#6-configuration)
7. [Alerting](#7-alerting)
8. [Dashboards](#8-dashboards)
9. [Verifying the stack](#9-verifying-the-stack)
10. [Day-2 operations](#10-day-2-operations)
11. [Troubleshooting](#11-troubleshooting)
12. [Security notes](#12-security-notes)
13. [Limitations and next steps](#13-limitations-and-next-steps)

---

## 1. How it works

### Architecture

```mermaid
flowchart LR
    subgraph node["Every Kubernetes node"]
        CL["Container logs<br/>/var/log/containers/*.log"]
        FB["Fluent Bit<br/>(DaemonSet)"]
        KL["Kubelet + cAdvisor<br/>(CPU / memory / network)"]
        CL --> FB
    end

    FB -- "push logs<br/>(HTTP :3100)" --> LOKI["Loki"]
    PROM["Prometheus"] -- "scrape metrics" --> FB
    PROM -- "scrape metrics" --> KL
    PROM -- "scrape metrics" --> LOKI
    PROM -- "scrape metrics" --> AM["Alertmanager"]
    PROM -- "scrape metrics" --> GRAF["Grafana"]

    PROM -- "metric alerts" --> AM
    LOKI -- "log alerts (ruler)" --> AM
    AM -- "notify" --> OUT["Email / Slack / Webhook"]

    GRAF -- "query metrics" --> PROM
    GRAF -- "query logs" --> LOKI
    GRAF -- "show alerts" --> AM

    subgraph disk["Local disk: /data/observability"]
        D1[(prometheus/)]
        D2[(loki/)]
        D3[(alertmanager/)]
        D4[(grafana/)]
        D5[(fluent-bit/)]
    end
    PROM -.-> D1
    LOKI -.-> D2
    AM -.-> D3
    GRAF -.-> D4
    FB -.-> D5
```

### The three data flows

**1. Logs: Fluent Bit → Loki → Grafana**

- Fluent Bit runs as a **DaemonSet** (one pod per node) and tails `/var/log/containers/*.log`. It understands both the `cri` (CRI-O, containerd) and `docker` log formats.
- The `kubernetes` filter asks the API server for pod metadata and attaches it to each log line.
- Every log line is pushed to Loki with these labels: `job="fluent-bit"`, `namespace`, `pod`, `container`, `node`.
- Fluent Bit keeps its **read position** (`flb_kube.db`) and a **disk buffer** in `/data/observability/fluent-bit` on each node. After a restart it continues where it stopped (no duplicates), and if Loki is down, logs wait on disk instead of being lost.
- Loki runs in single-binary mode and stores chunks and a TSDB index on the local filesystem. The compactor deletes logs older than `loki.retention` (default 7 days).

**2. Metrics: targets → Prometheus → Grafana**

Prometheus scrapes these jobs:

| Job | What it collects |
|---|---|
| `prometheus` | Prometheus' own metrics |
| `loki`, `alertmanager`, `grafana` | Health and internal metrics of each stack component |
| `fluent-bit` | Records sent, errors and retries per node (discovered automatically per DaemonSet pod) |
| `kubernetes-cadvisor` | **CPU, memory, network and throttling for every container**, via the API-server proxy |
| `kubernetes-nodes` | Kubelet metrics |
| `kubernetes-pods` | Any pod with the annotation `prometheus.io/scrape: "true"` (plus optional `prometheus.io/port` and `prometheus.io/path`) |

Prometheus runs with a ServiceAccount and ClusterRole so it can discover nodes and pods. Metrics are kept for `prometheus.retention` (default 15 days).

**3. Alerts: Prometheus + Loki → Alertmanager → you**

- **Prometheus** evaluates metric rules (pod CPU/memory, OOM kills, crash loops, node pressure, stack health).
- **Loki's ruler** evaluates LogQL rules (for example, "more than 50 error lines from one pod in 5 minutes").
- Both send firing alerts to **Alertmanager**, which groups them by `alertname`, `namespace` and `pod`, suppresses warnings when a matching critical alert fires, and delivers them to the receivers you enabled.
- **Grafana** has Alertmanager as a data source and shows all firing alerts on the home dashboard.

### Local-directory storage

Each stateful component gets a **hostPath PersistentVolume** pre-bound to its PVC:

| Directory on the node | Component | Contents | Owner (uid) |
|---|---|---|---|
| `/data/observability/prometheus` | Prometheus | Metrics TSDB | 65534 (nobody) |
| `/data/observability/loki` | Loki | Log chunks, index, compactor | 10001 |
| `/data/observability/alertmanager` | Alertmanager | Silences, notification log | 65534 (nobody) |
| `/data/observability/grafana` | Grafana | `grafana.db`, plugins | 472 |
| `/data/observability/fluent-bit` | Fluent Bit (every node) | Read positions, disk buffer | root |

- Directories are created automatically (`DirectoryOrCreate`).
- An **init container** sets the correct owner before each component starts, so there are no permission errors.
- `reclaimPolicy: Retain` plus hostPath means **data survives `helm uninstall`**. Reinstall with the same `basePath` and the old data is picked up again.
- Each Deployment uses the `Recreate` strategy so that only one pod at a time writes to its directory.

### Automatic restarts on config change

Every Deployment carries a `checksum/config` annotation computed from its ConfigMap or Secret. When you change a value and run `helm upgrade`, only the affected pods restart.

---

## 2. Repository structure

```
.
├── README.md                          # this document
├── .gitignore                         # keeps secrets and build output out of git
├── my-alert-values.example.yaml       # template for your private settings
├── scripts/
│   ├── install.sh                     # one-command install/upgrade (detects OS, SELinux, nodes)
│   ├── prepare-node.sh                # host prep: dirs, SELinux/AppArmor, inotify, firewall
│   ├── uninstall.sh                   # remove release (optionally purge data)
│   └── lib.sh                         # shared helpers (OS detection, logging)
└── observability-stack/               # the Helm chart
    ├── Chart.yaml
    ├── values.yaml                    # all defaults, fully commented
    ├── dashboards/
    │   ├── overview.json              # home dashboard: alerts, health, logs
    │   └── pod-resources.json         # CPU / memory / network per pod
    └── templates/
        ├── _helpers.tpl               # names, labels, shared snippets
        ├── NOTES.txt                  # message printed after install
        ├── storage.yaml               # StorageClass + hostPath PVs + PVCs
        ├── prometheus.yaml            # RBAC, Deployment, Service
        ├── prometheus-config.yaml     # scrape config + metric alert rules
        ├── alertmanager.yaml          # Deployment, Service
        ├── alertmanager-config.yaml   # routing + receivers (Secret)
        ├── loki.yaml                  # Deployment, Service
        ├── loki-config.yaml           # Loki config + log alert rules
        ├── fluent-bit.yaml            # RBAC, DaemonSet
        ├── fluent-bit-config.yaml     # inputs, filters, Loki output
        ├── grafana.yaml               # Deployment, Service
        └── grafana-config.yaml        # admin Secret, datasources, dashboards
```

**Kubernetes objects created** (release name `obs`, namespace `monitoring`):

| Kind | Count | Names |
|---|---|---|
| Deployment | 4 | `obs-observability-stack-{prometheus,alertmanager,loki,grafana}` |
| DaemonSet | 1 | `obs-observability-stack-fluent-bit` |
| Service | 4 | same names as the Deployments |
| PersistentVolume / PVC | 4 / 4 | `...-{prometheus,alertmanager,loki,grafana}-pv` / `...-data` |
| StorageClass | 1 | `local-observability` |
| ConfigMap / Secret | 5 / 2 | configs, dashboards, Grafana admin, Alertmanager config |
| ServiceAccount + ClusterRole + Binding | 2 each | Prometheus, Fluent Bit |

---

## 3. Prerequisites

- A **RHEL-family or Ubuntu/Debian** host (see the table at the top)
- A Kubernetes cluster, version 1.25 or newer (tested on 1.29 with CRI-O on RHEL 9)
- `kubectl` with cluster-admin rights, because the chart creates ClusterRoles, a StorageClass and PVs
- Helm 3.8 or newer. `scripts/install.sh` installs it automatically if it's missing.
- `root` or `sudo` on the storage node, for the host preparation step
- At least **4 GB of free memory** and **25 GB of free disk** under the storage path on the storage node
- The nodes can pull images from Docker Hub and `cr.fluentbit.io`

---

## 4. Quick start

### 4.1 Clone the repository

```bash
git clone https://github.com/<your-user>/<your-repo>.git
cd <your-repo>
```

### 4.2 Create your private settings file

```bash
cp my-alert-values.example.yaml my-alert-values.yaml
vi my-alert-values.yaml
```

At minimum, set the Grafana password. Email and Slack are optional and are covered in [section 7](#7-alerting).

> `my-alert-values.yaml` is listed in `.gitignore`. **Never commit it**, because it contains passwords.

### 4.3 Install: Option A, the install script (recommended, same command on RHEL and Ubuntu)

```bash
sudo ./scripts/install.sh
```

The script:

1. **Detects the OS** (RHEL family or Ubuntu/Debian), the **SELinux mode**, and how many nodes the cluster has.
2. **Finds kubectl's config** automatically for kubeadm (`/etc/kubernetes/admin.conf`), k3s and MicroK8s.
3. **Installs Helm** if it's missing.
4. **Prepares this node** by running `prepare-node.sh`:
   - creates `/data/observability/*` with the correct owners
   - on RHEL, labels the directory `container_file_t` for SELinux (persistent, via `semanage`)
   - raises the inotify limits (Ubuntu's default of 128 is too low for Fluent Bit)
   - opens ports 30300 and 30903 in **firewalld** (RHEL) or **ufw** (Ubuntu), if either is active
5. Runs `helm upgrade --install`, adding these settings automatically:
   - `selinux.enabled=true` when SELinux is **Enforcing**
   - `storage.nodeName=<this node>` on multi-node clusters
6. Waits for every pod and prints the Grafana URL and password.

Useful options:

```bash
sudo ./scripts/install.sh --dry-run                    # show what would happen, change nothing
sudo ./scripts/install.sh --node worker-1              # multi-node: store data on worker-1
sudo ./scripts/install.sh --base-path /mnt/disk1/obs   # different storage directory
sudo ./scripts/install.sh --values other-values.yaml   # different settings file
sudo ./scripts/install.sh --skip-firewall              # don't touch firewalld/ufw
```

**Multi-node clusters:** run the script on the node that should store the data (or pass `--node`). Then run the node preparation on every other node, since Fluent Bit runs on all of them:

```bash
sudo ./scripts/prepare-node.sh
```

### 4.4 Install: Option B, manual (plain Helm)

```bash
# 1. prepare the node (RHEL or Ubuntu - the script detects which)
sudo ./scripts/prepare-node.sh

# 2. check the chart
helm lint ./observability-stack -f my-alert-values.yaml

# 3a. Ubuntu / Debian, or RHEL with SELinux permissive/disabled
helm upgrade --install obs ./observability-stack -n monitoring --create-namespace \
  -f my-alert-values.yaml

# 3b. RHEL family with SELinux Enforcing (check with: getenforce)
helm upgrade --install obs ./observability-stack -n monitoring --create-namespace \
  -f my-alert-values.yaml --set selinux.enabled=true

# multi-node: add  --set storage.nodeName=<node-name>
```

`upgrade --install` installs the first time and upgrades on every later run, so you can always use the same command.

### 4.5 Open the firewall manually (only if you skipped `prepare-node.sh`)

**RHEL family (firewalld):**

```bash
sudo firewall-cmd --permanent --add-port=30300/tcp --add-port=30903/tcp
sudo firewall-cmd --reload
```

**Ubuntu / Debian (ufw):**

```bash
sudo ufw allow 30300/tcp
sudo ufw allow 30903/tcp
sudo ufw status
```

### 4.6 Wait for the pods

```bash
kubectl -n monitoring get pods,pvc -w
```

Expected result: 5 pods at `1/1 Running` and 4 PVCs `Bound`. The first start takes 1–2 minutes while images download. Loki reports ready about 30 seconds after it starts. `install.sh` waits for all of this automatically.

### 4.7 RHEL vs Ubuntu: what is different

| Topic | RHEL / Rocky / Alma / CentOS | Ubuntu / Debian | How the stack handles it |
|---|---|---|---|
| Security module | **SELinux**, Enforcing by default. Containers can't write to unlabelled host dirs or read `/var/log/pods`. | **AppArmor**. The default container profile allows hostPath access. | `prepare-node.sh` labels `/data/observability` as `container_file_t`; `selinux.enabled=true` runs pods as `spc_t`. Nothing is needed on Ubuntu. |
| Firewall | **firewalld** | **ufw** (often inactive) | `prepare-node.sh` opens the NodePorts in whichever is active |
| inotify limits | Usually 8192 instances | **128 instances**, which runs out and causes Fluent Bit "too many open files" errors | Raised to 512 / 524288 in `/etc/sysctl.d/99-observability.conf` |
| Package manager (for curl) | `dnf` | `apt-get` | Detected automatically |
| Container runtime | Usually CRI-O | Usually containerd (or Docker via cri-dockerd, k3s, MicroK8s) | Fluent Bit parses both `cri` and `docker` log formats and mounts `/var/log` and `/var/lib/docker/containers` |
| cgroups | v2 (RHEL 9), v1 (RHEL 8) | v2 (22.04+), v1 (20.04) | cAdvisor metrics and queries work on both |
| Kubeconfig location | kubeadm: `/etc/kubernetes/admin.conf` | kubeadm, k3s (`/etc/rancher/k3s/k3s.yaml`), MicroK8s | `install.sh` finds it automatically |

Everything else (the chart, images, dashboards and alerts) is identical on both.

**Distribution-specific notes**

- **k3s:** works as is. kubectl is `/usr/local/bin/kubectl`, and the kubeconfig is found automatically.
- **MicroK8s:** run `sudo snap alias microk8s.kubectl kubectl` and `sudo snap install helm --classic` first.
- **RHEL without `semanage`:** run `sudo dnf install -y policycoreutils-python-utils` for persistent labels. Otherwise the script falls back to `chcon`, which is lost on a full filesystem relabel.

---

## 5. Accessing the UIs

| UI | URL | Login |
|---|---|---|
| Grafana | `http://<node-ip>:30300` | `admin` / your `grafana.adminPassword` |
| Alertmanager | `http://<node-ip>:30903` | none |
| Prometheus | port-forward (below), then `http://<node-ip>:9090` | none |

```bash
# get the node IP
kubectl get nodes -o wide

# get the Grafana password
kubectl -n monitoring get secret obs-observability-stack-grafana \
  -o jsonpath='{.data.admin-password}' | base64 -d; echo

# Prometheus (runs in the foreground; use a second terminal)
kubectl -n monitoring port-forward svc/obs-observability-stack-prometheus 9090:9090 --address 0.0.0.0
```

To expose Prometheus permanently instead, set `prometheus.service.type: NodePort` and `prometheus.service.nodePort: 30090`.

---

## 6. Configuration

All settings live in `observability-stack/values.yaml`. Override them in `my-alert-values.yaml` or with `--set`.

### 6.1 Storage

| Key | Default | Description |
|---|---|---|
| `storage.basePath` | `/data/observability` | Parent directory on the node |
| `storage.nodeName` | `""` | Node that holds the data. **Required on multi-node clusters.** |
| `storage.storageClassName` | `local-observability` | StorageClass created for the PVs |
| `storage.createStorageClass` | `true` | Set to `false` if the class already exists |
| `storage.reclaimPolicy` | `Retain` | Keep data when PVs are deleted |
| `selinux.enabled` | `false` | Run pods as SELinux type `spc_t`. Needed on SELinux-**Enforcing** hosts (RHEL family). Ignored on Ubuntu/Debian. Set automatically by `install.sh`. |
| `<component>.storageSize` | 10Gi / 10Gi / 1Gi / 2Gi | Declared size for Prometheus / Loki / Alertmanager / Grafana (hostPath does not enforce it) |

### 6.2 Retention and scraping

| Key | Default | Description |
|---|---|---|
| `prometheus.retention` | `15d` | How long metrics are kept |
| `prometheus.scrapeInterval` | `30s` | Scrape and rule-evaluation interval |
| `loki.retention` | `168h` | How long logs are kept (7 days) |

### 6.3 Services

| Key | Default |
|---|---|
| `grafana.service.type` / `nodePort` | `NodePort` / `30300` |
| `alertmanager.service.type` / `nodePort` | `NodePort` / `30903` |
| `prometheus.service.type` | `ClusterIP` |
| `loki.service.type` | `ClusterIP` |

### 6.4 Images and resources

Each component has `image` and `resources` keys. For example:

```yaml
loki:
  image: grafana/loki:3.1.1
  resources:
    requests: { cpu: 100m, memory: 256Mi }
    limits:   { memory: 1Gi }
```

### 6.5 Scraping your own applications

Add these annotations to your application's pod template and Prometheus picks it up automatically:

```yaml
metadata:
  annotations:
    prometheus.io/scrape: "true"
    prometheus.io/port: "8080"      # the port serving metrics
    prometheus.io/path: "/metrics"  # optional, /metrics is the default
```

Application logs need no configuration: anything written to stdout or stderr is collected by Fluent Bit.

---

## 7. Alerting

### 7.1 Receivers

Enable one or more receivers in `my-alert-values.yaml`. All enabled receivers get every alert.

**Email (Gmail example)**

```yaml
alerting:
  email:
    enabled: true
    to: ops-team@yourcompany.com
    from: yourgmail@gmail.com
    smarthost: smtp.gmail.com:587
    authUsername: yourgmail@gmail.com
    authPassword: "abcd efgh ijkl mnop"   # Gmail App Password
    requireTLS: true
```

Gmail requires an **App Password**, not your normal password. Turn on 2-Step Verification, then create one at Google Account → Security → App passwords. For Office 365, use `smtp.office365.com:587`.

**Slack**

```yaml
alerting:
  slack:
    enabled: true
    webhookUrl: https://hooks.slack.com/services/XXX/YYY/ZZZ
    channel: "#alerts"
```

Create the webhook at <https://api.slack.com/messaging/webhooks>.

**Generic webhook** (Microsoft Teams via a proxy, PagerDuty bridge, a custom app, and so on)

```yaml
alerting:
  webhook:
    enabled: true
    url: http://my-receiver.example.com/alerts
```

**Full custom Alertmanager config:** if you need multiple routes or teams, put a complete `alertmanager.yml` in `alerting.configOverride`. It replaces the generated config.

**Timing**

| Key | Default | Meaning |
|---|---|---|
| `alerting.groupWait` | `30s` | Wait before sending the first notification for a new group |
| `alerting.groupInterval` | `5m` | Wait before sending updates about a group |
| `alerting.repeatInterval` | `4h` | Re-send while an alert is still firing |

### 7.2 Built-in alert rules

**Stack health (Prometheus)**

| Alert | Severity | Fires when |
|---|---|---|
| `TargetDown` | critical | A scrape target is down for 2 minutes |
| `PrometheusConfigReloadFailed` | warning | A Prometheus config reload failed |
| `PrometheusAlertmanagerNotConnected` | critical | Prometheus has no Alertmanager for 5 minutes |
| `PrometheusNotificationsFailing` | warning | Prometheus cannot send alerts to Alertmanager |
| `AlertmanagerNotificationsFailing` | critical | Email, Slack or webhook delivery keeps failing |
| `FluentBitOutputErrors` | warning | Fluent Bit gets errors from Loki for 10 minutes |
| `FluentBitLogsDropped` | critical | Fluent Bit gave up retrying and dropped logs |
| `FluentBitNotShippingLogs` | warning | A node has sent no logs for 15 minutes |
| `LokiRequestErrors` | warning | More than 5% of Loki requests fail |
| `LokiDiscardingLogs` | warning | Loki rejects incoming logs (rate limit, too old, and so on) |

**Pods and containers (Prometheus / cAdvisor)**

| Alert | Severity | Fires when (default threshold) |
|---|---|---|
| `PodHighCpu` | warning | Pod uses more than `podCpuCores` (1) cores for 10 minutes |
| `PodHighMemory` | warning | Pod uses more than `podMemoryMi` (2048 MiB) for 10 minutes |
| `ContainerCpuNearLimit` | warning | Container is above `podCpuPercentOfLimit` (90%) of its CPU limit |
| `ContainerMemoryNearLimit` | critical | Container is above `podMemoryPercentOfLimit` (90%) of its memory limit |
| `ContainerCpuThrottled` | warning | Container is throttled more than `cpuThrottlingPercent` (25%) of the time |
| `ContainerOOMKilled` | critical | Container was killed for running out of memory |
| `ContainerRestartingFrequently` | critical | More than `containerRestartsIn15m` (3) restarts in 15 minutes |

The "near limit" and throttling alerts only apply to containers that have limits set.

**Nodes (Prometheus / cAdvisor)**

| Alert | Severity | Fires when |
|---|---|---|
| `NodeHighCpu` | warning | Node CPU above `nodeCpuPercent` (85%) for 10 minutes |
| `NodeHighMemory` | critical | Node memory above `nodeMemoryPercent` (90%) for 10 minutes |

**Logs (Loki ruler)**

| Alert | Severity | Fires when |
|---|---|---|
| `HighErrorLogRate` | warning | A pod logs more than `errorLogsPer5m` (50) lines matching `error`, `exception`, `fatal` or `panic` in 5 minutes |
| `OutOfMemoryInLogs` | critical | A pod logs `out of memory`, `OutOfMemoryError` or `oom-kill` |

### 7.3 Changing thresholds

```yaml
alertRules:
  thresholds:
    podCpuCores: 2
    podMemoryMi: 4096
    nodeCpuPercent: 90
    errorLogsPer5m: 100
```

Set `alertRules.enabled: false` to turn off all built-in rules.

### 7.4 Adding your own rules

**Metric rule (PromQL):**

```yaml
alertRules:
  extraPrometheusRules:
    - name: my-app
      rules:
        - alert: MyAppDown
          expr: up{job="kubernetes-pods", app="my-app"} == 0
          for: 2m
          labels: { severity: critical }
          annotations:
            summary: "my-app is down"
```

**Log rule (LogQL):**

```yaml
alertRules:
  extraLokiRules:
    - name: payments
      rules:
        - alert: PaymentFailures
          expr: sum(count_over_time({namespace="payments"} |= "payment failed" [5m])) > 5
          for: 1m
          labels: { severity: critical }
          annotations:
            summary: "More than 5 payment failures in 5 minutes"
```

Apply the changes with `helm upgrade` (see [section 10](#10-day-2-operations)).

### 7.5 Silencing alerts

To silence an alert during maintenance, open Alertmanager at `http://<node-ip>:30903`, click **New Silence**, and add a matcher such as `alertname="NodeHighCpu"` with a duration. Silences are stored in `/data/observability/alertmanager` and survive restarts.

---

## 8. Dashboards

Dashboards are provisioned from `observability-stack/dashboards/*.json` into the Grafana folder **Observability Stack**.

**Observability Overview** (the Grafana home page) shows:
- Firing alerts from Prometheus and Loki, colored by severity
- UP/DOWN status of every stack component
- Fluent Bit → Loki throughput per node
- Log lines per namespace, and container CPU per namespace
- A log viewer with **Namespace** and **Search** filters

**Pod Resource Utilization** shows:
- Node CPU and memory used; CPU and memory of the selected pods
- CPU and memory per pod and per container over time
- CPU throttling percentage, and network receive/transmit per pod
- A "Top pods" table sorted by memory

You can filter it by namespace and pod at the top.

**Adding your own dashboard:** export it from Grafana as JSON (Share → Export → Save to file), put it in `observability-stack/dashboards/`, and run `helm upgrade`. Any `.json` file in that folder is loaded automatically.

**Useful queries in Grafana → Explore**

```promql
# CPU cores per pod
sum by (namespace, pod) (rate(container_cpu_usage_seconds_total{container!="",container!="POD"}[5m]))

# Memory per pod
sum by (namespace, pod) (container_memory_working_set_bytes{container!="",container!="POD"})

# Top 10 pods by memory
topk(10, sum by (namespace, pod) (container_memory_working_set_bytes{container!=""}))

# Currently firing alerts
ALERTS{alertstate="firing"}
```

```logql
# All logs from one namespace
{job="fluent-bit", namespace="default"}

# Errors from one pod
{job="fluent-bit", pod="my-pod-xyz"} |~ "(?i)error"

# Error count per namespace
sum by (namespace) (count_over_time({job="fluent-bit"} |~ "(?i)error" [5m]))
```

---

## 9. Verifying the stack

Run these checks after installing:

```bash
# 1. All pods running, all PVCs bound
kubectl -n monitoring get pods,pvc

# 2. Data is being written to the local directories
ls -la /data/observability/
du -sh /data/observability/*

# 3. Fluent Bit is shipping logs (look for "loki" output with no errors)
kubectl -n monitoring logs ds/obs-observability-stack-fluent-bit --tail=20

# 4. Loki is ready
kubectl -n monitoring exec deploy/obs-observability-stack-loki -- wget -qO- localhost:3100/ready

# 5. Prometheus targets: open http://<node-ip>:9090/targets (with the port-forward running)
#    prometheus, loki, alertmanager, grafana, fluent-bit, kubernetes-* should all be UP

# 6. Send a test alert
curl -XPOST http://<node-ip>:30903/api/v2/alerts -H 'Content-Type: application/json' \
  -d '[{"labels":{"alertname":"TestAlert","severity":"warning"},"annotations":{"summary":"Test alert"}}]'
```

For check 6, the alert should appear in the Alertmanager UI immediately and in your email or Slack within about 30 seconds.

In Grafana, go to **Explore → Loki** and run `{job="fluent-bit"}`. You should see log lines from your pods.

---

## 10. Day-2 operations

### Change settings

Edit `my-alert-values.yaml` (or `values.yaml`), then run the install script again:

```bash
sudo ./scripts/install.sh
```

Or use plain Helm (add `--set selinux.enabled=true` on SELinux-Enforcing hosts):

```bash
helm upgrade --install obs ./observability-stack -n monitoring -f my-alert-values.yaml
```

Only pods whose configuration changed are restarted.

### Status and history

```bash
helm list -n monitoring
helm status obs -n monitoring
helm history obs -n monitoring
helm get values obs -n monitoring      # values currently applied
```

### Roll back

```bash
helm rollback obs <revision> -n monitoring
```

### Upgrade component versions

Change the `image` tags in `values.yaml`, then run `helm upgrade`. Check each project's release notes first, especially for major versions of Loki and Grafana.

### Back up

All state is in plain directories, so a backup is a copy:

```bash
# scale down for a consistent copy
kubectl -n monitoring scale deploy --all --replicas=0
tar -czf observability-backup-$(date +%F).tgz -C /data observability
kubectl -n monitoring scale deploy --all --replicas=1
```

### Uninstall

```bash
sudo ./scripts/uninstall.sh                 # remove the release, keep data
sudo ./scripts/uninstall.sh --purge-data    # also delete the namespace, data, SELinux label rule and sysctl file
```

Or with plain Helm:

```bash
helm uninstall obs -n monitoring
```

Your data in `/data/observability` is **kept**. To delete everything permanently:

```bash
helm uninstall obs -n monitoring
kubectl delete namespace monitoring
rm -rf /data/observability          # deletes all metrics, logs and dashboards
```

### Package the chart for sharing

```bash
helm package ./observability-stack        # creates observability-stack-<version>.tgz
```

You can attach the `.tgz` to a GitHub Release instead of committing it.

---

## 11. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `cannot re-use a name that is still in use` | The release already exists | Use `helm upgrade --install` instead of `helm install` |
| Pod `Pending`, PVC `Pending` | PV node affinity doesn't match any node | Check `storage.nodeName` matches `kubectl get nodes` exactly |
| Pod stuck in `Init:Error` or `CrashLoopBackOff` with `permission denied` | Directory ownership or SELinux | See the SELinux entry below; check `kubectl -n monitoring logs <pod> -c init-data-dir` |
| `permission denied` on RHEL with SELinux Enforcing | hostPath lacks the container SELinux label, or pods not running as `spc_t` | `sudo ./scripts/prepare-node.sh`, then reinstall with `--set selinux.enabled=true` (or use `install.sh`). Check denials with `sudo ausearch -m avc -ts recent` |
| Fluent Bit running but **no logs** on RHEL | SELinux blocks reading `/var/log/pods` | Same as above: `selinux.enabled=true` |
| Fluent Bit `too many open files` / `inotify_init` errors (common on **Ubuntu**) | inotify instance limit (default 128) | `sudo ./scripts/prepare-node.sh` on every node; check with `sysctl fs.inotify.max_user_instances` |
| Ports unreachable on Ubuntu | ufw active | `sudo ufw allow 30300/tcp && sudo ufw allow 30903/tcp` |
| `install.sh`: `kubectl cannot reach the cluster` | kubeconfig not found | `export KUBECONFIG=/etc/kubernetes/admin.conf` (kubeadm) or `/etc/rancher/k3s/k3s.yaml` (k3s), then run again with `sudo -E` |
| Loki `0/1 Running` for the first 30–60 seconds | Normal startup delay | Wait |
| No logs in Grafana | Fluent Bit cannot reach Loki or read log files | `kubectl -n monitoring logs ds/obs-observability-stack-fluent-bit`; check `ls /var/log/containers` on the node |
| `kubernetes-cadvisor` target DOWN | Missing RBAC or API-server proxy blocked | `kubectl get clusterrole obs-observability-stack-prometheus -o yaml`; check the error on the Prometheus targets page |
| Pod dashboards empty | cAdvisor target down, or the time range is too short | Fix the target; wait 5 minutes (queries use `rate(...[5m])`) |
| Grafana/Alertmanager unreachable from browser | Firewall | RHEL: `firewall-cmd --list-ports`; Ubuntu: `ufw status`. Open 30300 and 30903 |
| Email not delivered | Wrong SMTP credentials or Gmail blocking | `kubectl -n monitoring logs deploy/obs-observability-stack-alertmanager \| grep -i error`; use a Gmail App Password |
| `AlertmanagerNotificationsFailing` fires | Receiver misconfigured | Same as above; check the webhook URL or Slack hook |
| Changed a value but nothing happened | Upgrade not run, or wrong values file | `helm get values obs -n monitoring` to see what is applied |

**Useful debugging commands**

```bash
kubectl -n monitoring describe pod <pod>
kubectl -n monitoring logs <pod> --all-containers --tail=50
kubectl -n monitoring get events --sort-by=.lastTimestamp | tail -20
helm template obs ./observability-stack -n monitoring -f my-alert-values.yaml > rendered.yaml   # inspect the generated manifests
```

---

## 12. Security notes

- **Never commit `my-alert-values.yaml`**: it holds the Grafana password and SMTP or Slack credentials. It is listed in `.gitignore`; commit only `my-alert-values.example.yaml`.
- Change the default Grafana password (`changeme`) before exposing the NodePort.
- The Alertmanager config is stored in a Kubernetes **Secret**, not a ConfigMap.
- Prometheus, Loki, Alertmanager and the Grafana UI have no authentication beyond Grafana's login. Keep NodePorts on a trusted network, or put an Ingress with authentication in front of them.
- With `selinux.enabled=true`, pods run as SELinux type `spc_t` (not confined by SELinux). That is the usual trade-off for log collectors and hostPath storage on SELinux hosts; the host directories are still labelled correctly by `prepare-node.sh`.
- Fluent Bit runs as root with read-only access to `/var/log`. If your namespace enforces the `restricted` Pod Security Standard, label it:
  `kubectl label ns monitoring pod-security.kubernetes.io/enforce=privileged`

---

## 13. Limitations and next steps

- **Single node for storage.** hostPath data lives on one node, so Prometheus, Loki, Alertmanager and Grafana run as single replicas. For high availability, move to network storage (NFS, Ceph, Longhorn) or object storage for Loki.
- **No kube-state-metrics yet.** There are no alerts on Kubernetes object state (pod phase, deployment replicas, requests vs. usage). Adding kube-state-metrics is the natural next step.
- **No node-exporter yet.** Node disk space and filesystem metrics are not collected, so there is no "disk almost full" alert for `/data/observability`. Add node-exporter to get them.
- **hostPath does not enforce size.** The `storageSize` values are declarations only; monitor disk usage on the node.
