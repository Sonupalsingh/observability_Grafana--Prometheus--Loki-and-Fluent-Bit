# observability-stack chart

Prometheus + Alertmanager + Loki + Fluent Bit + Grafana with local-directory storage.

See the [main README](../README.md) and the [full documentation](../docs/DOCUMENTATION.md) for architecture, installation, configuration, alerting and troubleshooting.

```bash
helm upgrade --install obs ./observability-stack -n monitoring --create-namespace -f my-alert-values.yaml
```
