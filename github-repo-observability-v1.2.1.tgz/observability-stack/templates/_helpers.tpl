{{- define "obs.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "obs.fullname" -}}
{{- if contains .Chart.Name .Release.Name -}}
{{- .Release.Name | trunc 50 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 50 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/* usage: include "obs.selectorLabels" (dict "ctx" $ "component" "loki") */}}
{{- define "obs.selectorLabels" -}}
app.kubernetes.io/name: {{ include "obs.name" .ctx }}
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end -}}

{{- define "obs.labels" -}}
{{ include "obs.selectorLabels" . }}
helm.sh/chart: {{ printf "%s-%s" .ctx.Chart.Name .ctx.Chart.Version }}
app.kubernetes.io/managed-by: {{ .ctx.Release.Service }}
{{- end -}}

{{/* in-cluster service DNS names */}}
{{- define "obs.prometheusUrl" -}}
http://{{ include "obs.fullname" . }}-prometheus.{{ .Release.Namespace }}.svc:{{ .Values.prometheus.service.port }}
{{- end -}}
{{- define "obs.lokiHost" -}}
{{ include "obs.fullname" . }}-loki.{{ .Release.Namespace }}.svc
{{- end -}}

{{/* pin pods to the storage node when configured */}}
{{- define "obs.nodeSelector" -}}
{{- with .Values.storage.nodeName }}
nodeSelector:
  kubernetes.io/hostname: {{ . | quote }}
{{- end }}
{{- end -}}

{{/* init container that prepares the local directory: include "obs.initDir" (dict "ctx" $ "uid" 472) */}}
{{- define "obs.initDir" -}}
- name: init-data-dir
  image: {{ .ctx.Values.initImage }}
  imagePullPolicy: {{ .ctx.Values.imagePullPolicy }}
  command: ["sh", "-c", "mkdir -p /data && chown -R {{ .uid }}:{{ .uid }} /data && chmod 0775 /data"]
  securityContext:
    runAsUser: 0
  volumeMounts:
    - name: data
      mountPath: /data
{{- end -}}

{{- define "obs.alertmanagerUrl" -}}
http://{{ include "obs.fullname" . }}-alertmanager.{{ .Release.Namespace }}.svc:{{ .Values.alertmanager.service.port }}
{{- end -}}

{{/* SELinux options for pods on SELinux-enforcing hosts (RHEL family) */}}
{{- define "obs.seLinux" -}}
{{- if .Values.selinux.enabled }}
seLinuxOptions:
  type: {{ .Values.selinux.type }}
{{- end }}
{{- end -}}
