#!/usr/bin/env bash
# One-command install/upgrade on RHEL-family or Ubuntu/Debian.
#
#   sudo ./scripts/install.sh [--values FILE] [--node NODE_NAME] [--release obs] [--namespace monitoring]
#                             [--base-path DIR] [--skip-prepare] [--skip-firewall] [--dry-run]
#
# What it does:
#   1. detects the OS, SELinux mode and cluster size
#   2. installs helm if missing
#   3. prepares this node (dirs, SELinux labels, inotify, firewall) via prepare-node.sh
#   4. runs: helm upgrade --install  (adds selinux.enabled / storage.nodeName automatically)
#   5. waits for all pods and prints the URLs
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=lib.sh
. "$SCRIPT_DIR/lib.sh"

RELEASE="${RELEASE:-obs}"
NAMESPACE="${NAMESPACE:-monitoring}"
BASE_PATH="${BASE_PATH:-/data/observability}"
VALUES_FILE="${VALUES_FILE:-$REPO_DIR/my-alert-values.yaml}"
CHART_DIR="$REPO_DIR/observability-stack"
NODE_NAME=""
SKIP_PREPARE=0
PREP_ARGS=()

while [ $# -gt 0 ]; do
  case "$1" in
    --values)        VALUES_FILE="$2"; shift 2 ;;
    --node)          NODE_NAME="$2"; shift 2 ;;
    --release)       RELEASE="$2"; shift 2 ;;
    --namespace)     NAMESPACE="$2"; shift 2 ;;
    --base-path)     BASE_PATH="$2"; shift 2 ;;
    --skip-prepare)  SKIP_PREPARE=1; shift ;;
    --skip-firewall) PREP_ARGS+=(--skip-firewall); shift ;;
    --dry-run)       DRY_RUN=1; shift ;;
    -h|--help)       sed -n '2,13p' "$0"; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done
export DRY_RUN

require_root "$@"
detect_os
info "OS: $OS_NAME ($OS_FAMILY)  |  SELinux: $(selinux_mode)"
[ -f "$CHART_DIR/Chart.yaml" ] || die "Chart not found at $CHART_DIR"

# ---------------------------------------------------------------- tools
have kubectl || die "kubectl not found. Install it (or on k3s: export PATH=\$PATH:/usr/local/bin; on microk8s: snap alias microk8s.kubectl kubectl)"
if [ -z "${KUBECONFIG:-}" ] && [ ! -f "$HOME/.kube/config" ]; then
  for k in /etc/kubernetes/admin.conf /etc/rancher/k3s/k3s.yaml /var/snap/microk8s/current/credentials/client.config; do
    if [ -f "$k" ]; then export KUBECONFIG="$k"; info "Using kubeconfig $k"; break; fi
  done
fi
kubectl get nodes >/dev/null 2>&1 || die "kubectl cannot reach the cluster (check KUBECONFIG)"

if ! have helm; then
  info "helm not found - installing Helm 3"
  if ! have curl; then
    if [ "$OS_FAMILY" = "rhel" ]; then run dnf -y install curl; else run apt-get install -y curl; fi
  fi
  if [ "$DRY_RUN" = "1" ]; then echo "   + curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash"
  else curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash; fi
  export PATH="$PATH:/usr/local/bin"
fi
ok "kubectl $(kubectl version --client -o yaml 2>/dev/null | awk '/gitVersion/{print $2; exit}')  |  helm $(helm version --short 2>/dev/null || echo '(dry-run)')"

# ---------------------------------------------------------------- cluster facts
mapfile -t NODES < <(kubectl get nodes -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}')
info "Cluster nodes (${#NODES[@]}): ${NODES[*]}"
SET_ARGS=(--set "storage.basePath=$BASE_PATH")

if [ -z "$NODE_NAME" ] && [ "${#NODES[@]}" -gt 1 ]; then
  for h in "$(hostname)" "$(hostname -f 2>/dev/null || true)" "$(hostname -s 2>/dev/null || true)"; do
    for n in "${NODES[@]}"; do
      if [ -n "$h" ] && [ "$h" = "$n" ]; then NODE_NAME="$n"; fi
    done
  done
  [ -n "$NODE_NAME" ] || die "Multi-node cluster: pass --node <one of: ${NODES[*]}> (the node whose disk stores the data)"
  info "Multi-node cluster: storing data on this node ($NODE_NAME)"
fi
if [ -n "$NODE_NAME" ]; then SET_ARGS+=(--set "storage.nodeName=$NODE_NAME"); fi

if [ "$(selinux_mode)" = "Enforcing" ]; then
  SET_ARGS+=(--set selinux.enabled=true)
  info "SELinux Enforcing -> selinux.enabled=true"
fi

VAL_ARGS=()
if [ -f "$VALUES_FILE" ]; then
  VAL_ARGS=(-f "$VALUES_FILE"); info "Values file: $VALUES_FILE"
else
  warn "No values file at $VALUES_FILE - using defaults (Grafana password 'changeme', no alert receivers)"
  warn "Create one:  cp $REPO_DIR/my-alert-values.example.yaml $REPO_DIR/my-alert-values.yaml"
fi

# ---------------------------------------------------------------- prepare this node
if [ "$SKIP_PREPARE" = "0" ]; then
  GP="$(awk '/^grafana:/{g=1} g&&/nodePort:/{print $2; exit}' "$CHART_DIR/values.yaml")"
  AP="$(awk '/^alertmanager:/{g=1} g&&/nodePort:/{print $2; exit}' "$CHART_DIR/values.yaml")"
  if [ "$DRY_RUN" = "1" ]; then PREP_ARGS+=(--dry-run); fi
  bash "$SCRIPT_DIR/prepare-node.sh" --base-path "$BASE_PATH" --ports "${GP:-30300} ${AP:-30903}" \
       ${PREP_ARGS[@]+"${PREP_ARGS[@]}"}
  if [ "${#NODES[@]}" -gt 1 ]; then
    warn "Also run 'sudo ./scripts/prepare-node.sh' on the other nodes (inotify limits for Fluent Bit)"
  fi
fi

# ---------------------------------------------------------------- helm
info "Linting chart"
run helm lint "$CHART_DIR" ${VAL_ARGS[@]+"${VAL_ARGS[@]}"} "${SET_ARGS[@]}"

info "Installing / upgrading release '$RELEASE' in namespace '$NAMESPACE'"
run helm upgrade --install "$RELEASE" "$CHART_DIR" -n "$NAMESPACE" --create-namespace \
    ${VAL_ARGS[@]+"${VAL_ARGS[@]}"} "${SET_ARGS[@]}"

if [ "$DRY_RUN" = "1" ]; then ok "Dry run finished - nothing was changed"; exit 0; fi

info "Waiting for pods (up to 5 minutes, first run downloads images)"
FULL="$RELEASE-observability-stack"
if [[ "$RELEASE" == *observability-stack* ]]; then FULL="$RELEASE"; fi
for d in prometheus alertmanager loki grafana; do
  kubectl -n "$NAMESPACE" rollout status "deploy/$FULL-$d" --timeout=300s || warn "$d not ready yet - check: kubectl -n $NAMESPACE describe pod -l app.kubernetes.io/component=$d"
done
kubectl -n "$NAMESPACE" rollout status "ds/$FULL-fluent-bit" --timeout=180s || warn "fluent-bit not ready yet"

kubectl -n "$NAMESPACE" get pods,pvc
IP="$(kubectl get node "${NODE_NAME:-${NODES[0]}}" -o jsonpath='{.status.addresses[?(@.type=="InternalIP")].address}')"
PASS="$(kubectl -n "$NAMESPACE" get secret "$FULL-grafana" -o jsonpath='{.data.admin-password}' | base64 -d)"
echo
ok "Done!"
echo "   Grafana:      http://$IP:${GP:-30300}   (user: admin  password: $PASS)"
echo "   Alertmanager: http://$IP:${AP:-30903}"
echo "   Prometheus:   kubectl -n $NAMESPACE port-forward svc/$FULL-prometheus 9090:9090 --address 0.0.0.0"
