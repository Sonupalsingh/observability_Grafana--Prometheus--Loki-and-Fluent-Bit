#!/usr/bin/env bash
# Remove the observability stack.
#
#   sudo ./scripts/uninstall.sh                 # remove release, KEEP data in /data/observability
#   sudo ./scripts/uninstall.sh --purge-data    # also delete namespace + all stored metrics/logs/dashboards
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "$SCRIPT_DIR/lib.sh"

RELEASE="${RELEASE:-obs}"; NAMESPACE="${NAMESPACE:-monitoring}"; BASE_PATH="${BASE_PATH:-/data/observability}"
PURGE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --purge-data) PURGE=1; shift ;;
    --release)    RELEASE="$2"; shift 2 ;;
    --namespace)  NAMESPACE="$2"; shift 2 ;;
    --base-path)  BASE_PATH="$2"; shift 2 ;;
    -h|--help)    sed -n '2,5p' "$0"; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

info "Uninstalling release $RELEASE from $NAMESPACE"
helm uninstall "$RELEASE" -n "$NAMESPACE" || warn "release not found"

if [ "$PURGE" = "1" ]; then
  require_root
  read -r -p "Delete namespace '$NAMESPACE' and ALL data in $BASE_PATH? Type 'yes': " ans
  [ "$ans" = "yes" ] || die "Aborted"
  kubectl delete namespace "$NAMESPACE" --ignore-not-found
  rm -rf "$BASE_PATH"
  if have semanage; then semanage fcontext -d "${BASE_PATH}(/.*)?" 2>/dev/null || true; fi
  rm -f /etc/sysctl.d/99-observability.conf
  ok "Everything removed (firewall ports left open - close them manually if needed)"
else
  ok "Release removed. Data kept in $BASE_PATH - reinstall to reuse it."
fi
