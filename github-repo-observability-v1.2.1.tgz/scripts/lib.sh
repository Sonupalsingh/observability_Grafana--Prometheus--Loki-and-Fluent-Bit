#!/usr/bin/env bash
# Shared helpers for install.sh / prepare-node.sh / uninstall.sh

DRY_RUN="${DRY_RUN:-0}"

c_green='\033[0;32m'; c_yellow='\033[0;33m'; c_red='\033[0;31m'; c_blue='\033[0;34m'; c_off='\033[0m'
info()  { echo -e "${c_blue}==>${c_off} $*"; }
ok()    { echo -e "${c_green} ✔${c_off} $*"; }
warn()  { echo -e "${c_yellow} !${c_off} $*" >&2; }
die()   { echo -e "${c_red} ✖ $*${c_off}" >&2; exit 1; }

# run a command, or just print it in dry-run mode
run() {
  echo "   + $*"
  if [ "$DRY_RUN" != "1" ]; then "$@"; fi
}

have() { command -v "$1" >/dev/null 2>&1; }

require_root() {
  if [ "$(id -u)" -ne 0 ] && [ "$DRY_RUN" != "1" ]; then
    die "Run as root (or with sudo): sudo $0 $*"
  fi
}

# Sets OS_ID, OS_NAME, OS_FAMILY (rhel | debian | other)
# shellcheck disable=SC2034
detect_os() {
  OS_ID="unknown"; OS_NAME="unknown"; OS_FAMILY="other"
  local f="${OS_RELEASE_FILE:-/etc/os-release}"
  if [ -r "$f" ]; then
    # shellcheck disable=SC1090
    . "$f"
    OS_ID="${ID:-unknown}"
    OS_NAME="${PRETTY_NAME:-$OS_ID}"
    case " ${ID:-} ${ID_LIKE:-} " in
      *" rhel "*|*" centos "*|*" fedora "*|*" rocky "*|*" almalinux "*|*" ol "*) OS_FAMILY="rhel" ;;
      *" debian "*|*" ubuntu "*) OS_FAMILY="debian" ;;
    esac
  fi
}

# Prints Enforcing | Permissive | Disabled
selinux_mode() {
  if have getenforce; then getenforce 2>/dev/null || echo Disabled; else echo Disabled; fi
}
