#!/usr/bin/env bash
# Prepare a node (RHEL family or Ubuntu/Debian) for the observability stack.
# Run it on EVERY node (Fluent Bit runs everywhere); install.sh runs it on the local node.
#
#   sudo ./scripts/prepare-node.sh [--base-path DIR] [--ports "30300 30903"] [--skip-firewall] [--dry-run]
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "$SCRIPT_DIR/lib.sh"

BASE_PATH="${BASE_PATH:-/data/observability}"
PORTS="${PORTS:-30300 30903}"
SKIP_FIREWALL=0

while [ $# -gt 0 ]; do
  case "$1" in
    --base-path)     BASE_PATH="$2"; shift 2 ;;
    --ports)         PORTS="$2"; shift 2 ;;
    --skip-firewall) SKIP_FIREWALL=1; shift ;;
    --dry-run)       DRY_RUN=1; shift ;;
    -h|--help)       sed -n '2,6p' "$0"; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done
export DRY_RUN

require_root "$@"
detect_os
info "Host: $(hostname)  |  OS: $OS_NAME  |  family: $OS_FAMILY  |  SELinux: $(selinux_mode)"
if [ "$OS_FAMILY" = "other" ]; then warn "OS not recognised as RHEL-family or Ubuntu/Debian - continuing with generic steps"; fi

# ---------------------------------------------------------------- 1. directories
info "1/4 Creating local storage directories under $BASE_PATH"
run mkdir -p "$BASE_PATH"/{prometheus,alertmanager,loki,grafana,fluent-bit}
run chown 65534:65534 "$BASE_PATH/prometheus" "$BASE_PATH/alertmanager"   # nobody
run chown 10001:10001 "$BASE_PATH/loki"
run chown 472:472     "$BASE_PATH/grafana"
run chown 0:0         "$BASE_PATH/fluent-bit"
run chmod 0775 "$BASE_PATH"/{prometheus,alertmanager,loki,grafana,fluent-bit}
ok "directories ready"

# ---------------------------------------------------------------- 2. SELinux / AppArmor
info "2/4 Security module"
SEL="$(selinux_mode)"
if [ "$SEL" != "Disabled" ]; then
  # container_file_t (RHEL 8/9) - older systems call it svirt_sandbox_file_t
  SE_TYPE="container_file_t"
  if have seinfo && ! seinfo -t container_file_t >/dev/null 2>&1; then SE_TYPE="svirt_sandbox_file_t"; fi
  if have semanage; then
    run semanage fcontext -a -t "$SE_TYPE" "${BASE_PATH}(/.*)?" 2>/dev/null \
      || run semanage fcontext -m -t "$SE_TYPE" "${BASE_PATH}(/.*)?"
    run restorecon -R "$BASE_PATH"
    ok "SELinux ($SEL): $BASE_PATH labelled $SE_TYPE (persistent, survives relabel)"
  else
    run chcon -R -t "$SE_TYPE" "$BASE_PATH"
    warn "semanage not found (dnf install policycoreutils-python-utils) - used chcon (not persistent across full relabel)"
  fi
  if [ "$SEL" = "Enforcing" ]; then
    warn "SELinux is Enforcing: install with --set selinux.enabled=true (install.sh does this automatically)"
  fi
elif have aa-status && aa-status --enabled 2>/dev/null; then
  ok "AppArmor active (Ubuntu/Debian) - default container profile allows hostPath access, nothing to change"
else
  ok "No SELinux/AppArmor restrictions detected"
fi

# ---------------------------------------------------------------- 3. inotify limits
info "3/4 Kernel inotify limits (Fluent Bit tails many log files)"
cur_inst="$(sysctl -n fs.inotify.max_user_instances 2>/dev/null || echo 0)"
cur_watch="$(sysctl -n fs.inotify.max_user_watches 2>/dev/null || echo 0)"
if [ "$cur_inst" -lt 512 ] || [ "$cur_watch" -lt 524288 ]; then
  if [ "$DRY_RUN" = "1" ]; then
    echo "   + write /etc/sysctl.d/99-observability.conf (max_user_instances=512, max_user_watches=524288)"
  else
    cat > /etc/sysctl.d/99-observability.conf <<CONF
# observability-stack: Fluent Bit tails every container log file
fs.inotify.max_user_instances = 512
fs.inotify.max_user_watches = 524288
CONF
  fi
  run sysctl -p /etc/sysctl.d/99-observability.conf
  ok "raised (was instances=$cur_inst watches=$cur_watch)"
else
  ok "already sufficient (instances=$cur_inst watches=$cur_watch)"
fi

# ---------------------------------------------------------------- 4. firewall
info "4/4 Firewall (NodePorts: $PORTS)"
if [ "$SKIP_FIREWALL" = "1" ]; then
  ok "skipped (--skip-firewall)"
elif have firewall-cmd && systemctl is-active --quiet firewalld 2>/dev/null; then
  for p in $PORTS; do run firewall-cmd --permanent --add-port="${p}/tcp"; done
  run firewall-cmd --reload
  ok "firewalld: ports opened"
elif have ufw && ufw status 2>/dev/null | grep -q "Status: active"; then
  for p in $PORTS; do run ufw allow "${p}/tcp"; done
  ok "ufw: ports opened"
else
  ok "no active firewalld/ufw - nothing to open"
fi

# ---------------------------------------------------------------- checks
if [ ! -d /var/log/containers ] && [ ! -d /var/log/pods ]; then
  warn "/var/log/containers not found yet - normal before the first pod runs, otherwise check your container runtime"
fi
ok "Node $(hostname) is ready"
